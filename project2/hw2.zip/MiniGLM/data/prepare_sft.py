### TODO: prepare SFT data similar to `prepare.py`
###
import os
import sys
import tiktoken
import numpy as np
import random
import json
import re


enc = tiktoken.get_encoding("gpt2")
sft_datas = []
with open('../../datasets/sft_data.jsonl','r',encoding='utf-8') as fp:
    for line in fp:
        datas = json.loads(line)
        sft_datas.append(datas)

datas = []
for data in sft_datas:
    #data['Question'] = '@' + data['Question']
    #data['Answer'] ='#' + data['Answer']
    #data['Question'] = data['Question'] + enc.decode([enc.eot_token])
    data['Answer'] = re.sub(r'\n','',data['Answer'])
    #data['Answer'] = data['Answer'] + enc.decode([enc.eot_token])
    datas.append(data['Question'] + data['Answer'])

#print(datas)
data_num = len(datas)
train_num = int(0.9*data_num)
train_data = datas[:train_num]
val_data = datas[train_num:]
#train_token = enc.encode_ordinary(' '.join(train_data))
#val_token = enc.encode_ordinary(' '.join(val_data))
train_token =[]
target1=0
target2=0
for data in train_data:
    token = enc.encode_ordinary(data)
    token = token + [enc.eot_token]
    train_token.append(np.array(token,dtype=np.int64))
val_token =[]
for data in val_data:
    token = enc.encode_ordinary(data)
    token = token + [enc.eot_token]
    val_token.append(np.array(token,dtype=np.int64))
def pad_or_cut(value, target):
    row = None
    if len(value)<=target: row = np.pad(value, [(0, target-len(value))])
    elif len(value)>target: 
        row = value[:target-1]
        row = np.concatenate((row,np.array([enc.eot_token])))
    return row
block_size = 512
train_token_pad = [pad_or_cut(arr,block_size) for arr in train_token]
val_token_pad = [pad_or_cut(arr,block_size) for arr in val_token]
train_ids = np.array(train_token_pad,dtype=np.int64)
val_ids = np.array(val_token_pad,dtype=np.int64)
train_ids.tofile(os.path.join("processed_sft", "train.bin"))
val_ids.tofile(os.path.join("processed_sft", 'val.bin'))








