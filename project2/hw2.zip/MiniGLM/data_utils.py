import os
import tiktoken
import torch
import numpy as np

train_data = None
val_data = None

def init_data_pretrain(dataset):
    global train_data, val_data
    
    data_dir = os.path.join('data', dataset)
    train_data = np.memmap(os.path.join(data_dir, 'train.bin'), dtype=np.int64, mode='r')
    val_data = np.memmap(os.path.join(data_dir, 'val.bin'), dtype=np.int64, mode='r')

def init_data_sft(dataset):
    global train_data, val_data
    
    ### TODO: 读取+初始化sft数据
    data_dir = os.path.join('data',dataset)
    train_data = np.memmap(os.path.join(data_dir, 'train.bin'), dtype=np.int64, mode='r')
    val_data = np.memmap(os.path.join(data_dir, 'val.bin'), dtype=np.int64, mode='r')
    #train_data, val_data = None, None 
    ##

def get_batch_pretrain(split, batch_size, block_size, device):
    global train_data, val_data
    data = train_data if split == 'train' else val_data
    ix = torch.randint(len(data) - block_size, (batch_size,))
    x = torch.stack([torch.from_numpy((data[i:i+block_size]).astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy((data[i+1:i+1+block_size]).astype(np.int64)) for i in ix])
    loss_mask = torch.ones_like(x, dtype=torch.float64)
    
    device_type = 'cuda' if 'cuda' in device else 'cpu'
    if device_type == 'cuda':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y, loss_mask = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True), loss_mask.pin_memory().to(device, non_blocking=True)
    else:
        x, y, loss_mask = x.to(device), y.to(device), loss_mask.to(device)
    return x, y, loss_mask
    
def get_batch_sft(split, batch_size, block_size, device): 
    ### TODO: 获取sft数据的批次（batch）+ 构建损失函数掩码（loss_mask）
    global train_data, val_data
    data = train_data if split == 'train' else val_data
    ix = torch.randint(len(data) - block_size, (batch_size,))
    x = torch.stack([torch.from_numpy((data[i:i+block_size]).astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy((data[i+1:i+1+block_size]).astype(np.int64)) for i in ix])
    loss_mask = torch.zeros_like(x, dtype=torch.float64)
    
    enc = tiktoken.get_encoding("gpt2")
    begin_token = enc.encode_ordinary('？')
    end_token = 50256
    len1,len2 = x.size()
    for i in range(len1):
        for j in range(len2):
            b = -4
            e = len2
            if x[i][j:j+3] == begin_token: b = j
            elif x[i][j]  == end_token: e = j
        loss_mask[i][b+4:e] = 1
    
    #begin_token = torch.tensor(begin_token)
    #end_token = torch.tensor(end_token)
    #begin_index = torch.where(x==begin_token)
    #end_index = torch.where(x==end_token)

    #begin_token = torch.tensor(begin_token)
    #end_token = torch.tensor(end_token)
    #begin_index = torch.nonzero(x==begin_token, as_tuple=False).squeeze()
    #end_index = torch.nonzero(x==end_token, as_tuple=False).squeeze()
    #begin_index = (x == begin_token).nonzero(as_tuple=False).squeeze()
    #end_index = (x == end_token).nonzero(as_tuple=False).squeeze()
    """
    for i in range(len(begin_index)):
        b = begin_index[i]
        e = end_index[i]
        loss_mask[b+1:e] = 1
    """
    

    device_type = 'cuda' if 'cuda' in device else 'cpu'
    if device_type == 'cuda':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y, loss_mask = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True), loss_mask.pin_memory().to(device, non_blocking=True)
    else:
        x, y, loss_mask = x.to(device), y.to(device), loss_mask.to(device)
    #x, y, loss_mask = None, None, None
    ###
    
    return x, y, loss_mask