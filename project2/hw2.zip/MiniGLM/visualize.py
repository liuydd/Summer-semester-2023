### TODO: add your import
import matplotlib.pyplot as plt


def visualize_loss(train_loss_list, train_interval, val_loss_list, val_interval, dataset, out_dir):
    ### TODO: visualize loss of training & validation and save to [out_dir]/loss.png
    ###
    x1 = range(0,5010,train_interval)
    x2 = range(0,5250,val_interval)
    y1 = train_loss_list
    y2 = val_loss_list
    plt.plot(x1,y1,marker='*',label='train loss')
    plt.plot(x2,y2,marker='*',label='val loss')
    plt.xlabel('interval')
    plt.ylabel('loss')
    plt.legend()
    plt.savefig('{}/loss.png'.format(out_dir))
