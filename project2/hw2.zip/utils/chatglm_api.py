import zhipuai
import json

zhipuai.api_key = "e7dd91fa71c5ced8d2472c5cdf1319ec.AxWiulKqtbMoEr3V"


text = '''请问《天龙八部》主要讲了什么故事？'''

response = zhipuai.model_api.invoke(
    model="chatglm_pro",
    prompt=[
        {"role": "user", "content": text},
    ],
    temperature=0.2,
    top_p=0.7,
    max_tokens=1000,
)
