### TODO: Implement metrics Perplexity, Rouge-L, etc.
###
import math
import torch
import os

ckpt_dir = 'out-1694754761'
ckpt_path = os.path.join(ckpt_dir, 'ckpt.pt')
checkpoint = torch.load(ckpt_path, map_location='cuda')
val_loss = checkpoint['best_val_loss']

def perl(loss):
    return math.exp(loss)

print('模型的ppl值为{}'.format(perl(val_loss)))


def get_lcs(seq1, seq2):
    len1 = len(seq1)
    len2 = len(seq2)
    dp = [[0 for _ in range(len2 + 1)] for _ in range(len1 + 1)]
    for i in range(1, len1 + 1):  
        for j in range(1, len2 + 1):  
            if seq1[i - 1] == seq2[j - 1]:  
                dp[i][j] = dp[i - 1][j - 1] + 1  
            else:  
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])  
    return dp[-1][-1]

def rouge_l(generation, reference, beta):
    lcs = get_lcs(generation,reference)
    r = lcs/len(generation)
    p = lcs/len(reference)
    Rouge_L = (1+beta*beta)*r*p/(r+beta*beta*p)
    return Rouge_L

r = '《天龙八部》中有许多主要角色，其中包括段誉、虚竹、乔峰、王语嫣、阿朱、阿紫等。每个角色都有独特的个性和故事线。'
with open('out-1694754761/samples','r',encoding='utf-8') as fp:
    for line in fp:
        print(rouge_l(line,r,0.99))



