import os
import sys
import tiktoken
import numpy as np
import random
import re
from string import punctuation

enc = tiktoken.get_encoding("gpt2")

names = sys.argv[1:]

### TODO: read data from ([name]/input.txt for name in names)
### TODO: combine multiple books into one single data file
### TODO: split data for train(0.9) and valid (0.1)
#punc = punctuation + u'.,;《》？！“”‘’@#￥%…&×（）——+【】{};；●，。&～、|\s:：'
datas = []
for name in names:
    file_path = f'{name}/input.txt'
    with open(file_path, 'r') as fp:
        data = fp.read()
        #data = re.sub(r'[{}]+'.format(punc),' ',data)
        data = re.sub(r'd+','',data)
        data = re.sub('\u3000','',data)
        data = re.sub(' ','',data)
        data = re.sub('\n','',data)
        datas.append(data)
combined_datas = ''.join(datas)
#print(combined_datas)
#print(len(combined_datas))
#split_datas = combined_datas.split('\n')
#print(split_datas)
data_num = len(combined_datas)
#print(data_num)
train_num = int(0.9*data_num)
train_data = combined_datas[:train_num]
val_data = combined_datas[train_num:]

#train_data, val_data = None, None
###

### TODO: tokenize raw data with tiktoken encoder
### TODO: transform to numpy array
train_token = enc.encode_ordinary(train_data)
val_token = enc.encode_ordinary(val_data)
train_ids = np.array(train_token,dtype=np.int64)
val_ids = np.array(val_token,dtype=np.int64)
#train_ids, val_ids = None, None
###

# save numpy array to file [name]/train.bin and [name]/val.bin
train_ids.tofile(os.path.join("processed_pretrain2", "train.bin"))
val_ids.tofile(os.path.join("processed_pretrain2", 'val.bin'))


