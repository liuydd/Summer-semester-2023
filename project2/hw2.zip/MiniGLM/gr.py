import gradio as gr
import torch
import os
import re
import tiktoken
from contextlib import nullcontext
from model import GLMConfig, MiniGLM

device = 'cuda' # examples: 'cpu', 'cuda', 'cuda:0', 'cuda:1', etc.
dtype = 'bfloat16' if torch.cuda.is_available() and torch.cuda.is_bf16_supported() else 'float16'
device_type = 'cuda' if 'cuda' in device else 'cpu' # for later use in torch.autocast
ptdtype = {'float32': torch.float32, 'bfloat16': torch.bfloat16, 'float16': torch.float16}[dtype]
ctx = nullcontext() if device_type == 'cpu' else torch.amp.autocast(device_type=device_type, dtype=ptdtype)
init_from = 'scratch'

exec(open('configurator.py').read())

if init_from == 'scratch':
    checkpoint = torch.load('out-pretrain/ckpt.pt') #预训练模型
elif init_from == 'finetune':
    checkpoint = torch.load('out-sft/ckpt.pt') #微调模型

config = GLMConfig(**checkpoint['model_args'])
model = MiniGLM(config)
state_dict = checkpoint['model']
unwanted_prefix = '_orig_mod.'
for k,v in list(state_dict.items()):
    if k.startswith(unwanted_prefix):
        state_dict[k[len(unwanted_prefix):]] = state_dict.pop(k)
model.load_state_dict(state_dict)

model.eval()
model.to(device)


enc = tiktoken.get_encoding("gpt2")
encode = lambda s: enc.encode(s, allowed_special={"<|endoftext|>"})
decode = lambda l: enc.decode(l)

def chat(question):
    if question[-1] =='。':
        question = question[:len(question)-1]
        question +='？'
    with torch.no_grad():
        with ctx:
            x = (torch.tensor(encode(question), dtype=torch.long, device=device)[None, ...])
            y = model.generate(x, 500, temperature=0.8, top_k=200)
            output_tokens = y[0].tolist()
            if init_from == 'finetune':
                input_tokens = x[0].tolist()
                output_tokens = output_tokens[len(input_tokens):]
            try:
                end_idx = output_tokens.index(50256)
                output_tokens = output_tokens[:end_idx]
            except:
                pass
            output = decode(output_tokens)
            output = re.sub(r'�','',output)   
    return output

demo = gr.Interface(
    fn=chat,
    inputs=["text"],
    outputs=["text"],
)

demo.launch()